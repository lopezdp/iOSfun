//
//  main.m
//  BMICalculator
//
//  Created by David P. Lopez on 9/25/16.
//  Copyright © 2016 David P. Lopez. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
