//
//  StatesTableViewController.h
//  USStatesAndFlags
//
//  Created by David P. Lopez on 11/4/16.
//  Copyright © 2016 David P. Lopez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StatesTableViewController : UITableViewController

@end
