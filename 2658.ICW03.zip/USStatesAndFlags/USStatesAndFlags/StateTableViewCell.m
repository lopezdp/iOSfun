//
//  StateTableViewCell.m
//  USStatesAndFlags
//
//  Created by David P. Lopez on 11/4/16.
//  Copyright © 2016 David P. Lopez. All rights reserved.
//

#import "StateTableViewCell.h"

@implementation StateTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
